1.使用前，请在设置中调整鼠标大小。日常使用推荐2，想要更清晰推荐4
2.右键文件“Right-click the file and select Install.inf”点击安装即可安装
3.下载后弹出鼠标属性，点击指针，切换到需要的主题后点击确定即可
4.指针由Circle Love Dose制作，绘制：Mooiny；动效及程序：Moodcutter；下载程序：bilibili UID：515958468。仅限非商用场景使用