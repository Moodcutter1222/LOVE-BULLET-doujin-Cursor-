Before use, please adjust the mouse cursor size in Settings. We recommend setting it to 2 for everyday use, or 4 for greater clarity.
Right-click the file named “Right-click the file and select Install.inf” and select “Install” to install it.
After downloading, the “Mouse Properties” window will pop up. Select the cursor, switch to the desired theme, and click OK to begin using the cursor.
This cursor was created by Circle Love Dose and is for non-commercial use only. 
Credits: 
Artwork by Mooiny
Animation and Programming by Moodcutter;
Download: Bilibili UID — 515958468.
Translation by d4ngerousblues.